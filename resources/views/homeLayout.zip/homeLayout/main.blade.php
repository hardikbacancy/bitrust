<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="" content="">
    <link rel="icon" href="home/images/favicon.png">

    <title>BiTrust</title>

    <!-- BOOTSTRAP -->
    <link href="home/js/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- CUSTOM STYLES -->
    <link href="home/css/style.css" rel="stylesheet">
    <link href="home/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<!-- START - Top area -->
<div class="top-container">
    <div class="container">
        <div class="top-column-left">
            <img src="home/images/logo.png" alt="Logo" />
        </div>
        <div class="top-column-right mt-5">
            <ul class="contact-line">

                <li><i class="fa fa-phone"></i> 123.567.8978</li>
                <li><i class="fa fa-envelope"></i> info@bitrust.ca</li>
            </ul>
            <div class="top-social-network">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
            </div>
        </div>
    </div>
</div>
<!-- END - Top area -->

<div class="clearfix"></div>

<!-- START - Navbar -->
<nav class="navbar navbar-default navbar-dark megamenu">
    <div class="container">


        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand logo" href="index.html">
                <img src="home/images/logo.png" alt="Logo" />
            </a>
        </div>


        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-menu">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="/">Home</a></li>
                <li><a href="/about-us">About Us</a></li>
                <li><a href="/who-we-are">Who we are</a></li>
                <li><a href="/contact-us">Contact Us</a></li>
                <li><a href="/login">Sign In/up</a></li>
            </ul>
        </div>
    </div>
</nav>
<!-- END - Navbar -->

@yield('content')

<footer>
    <div class="container">
        <div class="row">
            <div class="footer-content">
                <img class="footer-logo" src="home/images/footerlogo.png" alt="Footer logo">
                <p>4, 3101 STRANDHERD DR <br> Ottawa, ON K2G4R9</p>
                <ul class="menu">
                    <li> <a href="/">HOME</a> </li>
                    <li> <a href="#">About us </a> </li>
                    <li> <a href="#">Who We are</a> </li>
                    <li>  <a href="#">Contact US</a> </li>
                    <li> <a href="/login">SIGN IN / UP</a></li>
                </ul>
                <hr>
                <ul class="contact">
                    <li><i class="fa fa-phone"></i><a href="#">123.567.8978</a></li>
                    <li><i class="fa fa-phone"></i><a href="#"> info@bitrust.ca</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<div class="sub-footer">

    <p class="">© 2019 BI Trust. All Rights Reserved</p>

</div>
<!-- jQuery -->
<script src="home/js/jquery.min.js"></script>

<!-- BOOTSTRAP -->
<script src="home/js/bootstrap/js/bootstrap.min.js"></script>


</body>
</html>