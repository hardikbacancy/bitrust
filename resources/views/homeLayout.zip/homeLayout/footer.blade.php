<footer>
    <div class="container">
        <div class="row">
            <div class="footer-content">
                <img class="footer-logo" src="images/footerlogo.png" alt="Footer logo">
                <p>4, 3101 STRANDHERD DR <br> Ottawa, ON K2G4R9</p>
                <ul class="menu">
                    <li> HOME </li>
                    <li> About us  </li>
                    <li> Who We are </li>
                    <li> Contact US   </li>
                    <li> SIGN IN / UP</li>
                </ul>
                <hr>
                <ul class="contact">
                    <li><i class="fa fa-phone"></i><a href="#">123.567.8978</a></li>
                    <li><i class="fa fa-phone"></i><a href="#"> info@bitrust.ca</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<div class="sub-footer">

    <p class="">© 2019 BI Trust. All Rights Reserved</p>

</div>
<!-- jQuery -->
<script src="js/jquery.min.js"></script>

<!-- BOOTSTRAP -->
<script src="js/bootstrap/js/bootstrap.min.js"></script>
